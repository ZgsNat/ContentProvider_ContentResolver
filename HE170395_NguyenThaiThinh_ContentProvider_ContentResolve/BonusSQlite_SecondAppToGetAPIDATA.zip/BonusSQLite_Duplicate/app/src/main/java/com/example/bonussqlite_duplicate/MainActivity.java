package com.example.bonussqlite_duplicate;

import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        TextView textView = findViewById(R.id.textView);

        Uri uri = Uri.parse("content://com.example.bonussqlite_room.provider/products");
        Cursor cursor = getContentResolver().query(uri, null, null, null, null);

        if (cursor != null) {
            StringBuilder sb = new StringBuilder();
            while (cursor.moveToNext()) {
                String name = cursor.getString(cursor.getColumnIndexOrThrow("productName"));
                String description = cursor.getString(cursor.getColumnIndexOrThrow("productDescription"));
                double price = cursor.getDouble(cursor.getColumnIndexOrThrow("productPrice"));
                sb.append("Name: ").append(name).append("\n")
                        .append("Description: ").append(description).append("\n")
                        .append("Price: ").append(price).append("\n\n");
            }
            cursor.close();
            textView.setText(sb.toString());
        }
    }
}