package com.example.bonussqlite_room;

import android.content.ContentProvider;
import android.content.ContentUris;
import android.content.ContentValues;
import android.content.Context;
import android.content.UriMatcher;
import android.database.Cursor;
import android.net.Uri;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.room.Room;

import java.util.List;

public class ProductContentProvider extends ContentProvider {

    public static final String AUTHORITY = "com.example.bonussqlite_room.provider";
    public static final Uri CONTENT_URI = Uri.parse("content://" + AUTHORITY + "/products");
    private static final int PRODUCTS = 1;
    private static final int PRODUCT_ID = 2;
    private static final UriMatcher uriMatcher = new UriMatcher(UriMatcher.NO_MATCH);

    static {
        uriMatcher.addURI(AUTHORITY, "products", PRODUCTS);
        uriMatcher.addURI(AUTHORITY, "products/#", PRODUCT_ID);
    }

    private ProductDAO productDAO;

    @Override
    public boolean onCreate() {
        Context context = getContext();
        AppDatabase db = Room.databaseBuilder(context, AppDatabase.class, "goods.db").build();
        productDAO = db.productDAO();
        return true;
    }

    @Nullable
    @Override
    public Cursor query(@NonNull Uri uri, @Nullable String[] projection, @Nullable String selection, @Nullable String[] selectionArgs, @Nullable String sortOrder) {
        switch (uriMatcher.match(uri)) {
            case PRODUCTS:
                return productDAO.getAllProductsCursor();
            case PRODUCT_ID:
                long id = ContentUris.parseId(uri);
                return productDAO.getProductByIdCursor(id);
            default:
                throw new IllegalArgumentException("Unsupported URI: " + uri);
        }
    }

    @Nullable
    @Override
    public Uri insert(@NonNull Uri uri, @Nullable ContentValues values) {
        if (uriMatcher.match(uri) == PRODUCTS) {
            Product product = fromContentValues(values);
            long id = productDAO.insert(product);
            return ContentUris.withAppendedId(CONTENT_URI, id);
        }
        throw new IllegalArgumentException("Unsupported URI for insertion: " + uri);
    }

    @Override
    public int update(@NonNull Uri uri, @Nullable ContentValues values, @Nullable String selection, @Nullable String[] selectionArgs) {
        if (uriMatcher.match(uri) == PRODUCT_ID) {
            long id = ContentUris.parseId(uri);
            Product product = fromContentValues(values);
            product.id = (int) id;
            return productDAO.update(product);
        }
        throw new IllegalArgumentException("Unsupported URI for update: " + uri);
    }

    @Override
    public int delete(@NonNull Uri uri, @Nullable String selection, @Nullable String[] selectionArgs) {
        if (uriMatcher.match(uri) == PRODUCT_ID) {
            long id = ContentUris.parseId(uri);
            return productDAO.deleteById(id);
        }
        throw new IllegalArgumentException("Unsupported URI for deletion: " + uri);
    }

    @Nullable
    @Override
    public String getType(@NonNull Uri uri) {
        switch (uriMatcher.match(uri)) {
            case PRODUCTS:
                return "vnd.android.cursor.dir/vnd.com.example.bonussqlite_room.provider.products";
            case PRODUCT_ID:
                return "vnd.android.cursor.item/vnd.com.example.bonussqlite_room.provider.products";
            default:
                throw new IllegalArgumentException("Unsupported URI: " + uri);
        }
    }

    private Product fromContentValues(ContentValues values) {
        Product product = new Product();
        if (values.containsKey("name")) product.productName = values.getAsString("name");
        if (values.containsKey("description")) product.productDescription = values.getAsString("description");
        if (values.containsKey("price")) product.productPrice = values.getAsDouble("price");
        return product;
    }
}
