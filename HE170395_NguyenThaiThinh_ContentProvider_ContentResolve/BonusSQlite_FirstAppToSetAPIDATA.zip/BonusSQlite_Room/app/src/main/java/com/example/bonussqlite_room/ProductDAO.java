package com.example.bonussqlite_room;

// ProductDao.java
import android.database.Cursor;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;
import androidx.room.Delete;

import java.util.List;

@Dao
public interface ProductDAO {
    @Insert
    long insert(Product product);

    @Update
    int  update(Product product);

    @Delete
    int  delete(Product product);
    @Query("DELETE FROM product WHERE id = :id")
    int deleteById(long id);

    @Query("SELECT * FROM Product")
    List<Product> getAllProducts();
    @Query("SELECT * FROM product WHERE id = :id")
    Product getProductById(int id);

    @Query("SELECT * FROM product")
    Cursor getAllProductsCursor();

    @Query("SELECT * FROM product WHERE id = :id")
    Cursor getProductByIdCursor(long id);
}
